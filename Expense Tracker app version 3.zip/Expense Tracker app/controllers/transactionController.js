// controllers/transactionController.js
const Transaction = require('../models/Transaction');

// Get all transactions for user
exports.getTransactions = async (req, res) => {
    try {
        const userId = req.userId;
        const { type, category_id, startDate, endDate, limit, page } = req.query;
        
        const filters = {};
        if (type) filters.type = type;
        if (category_id) filters.category_id = parseInt(category_id);
        if (startDate) filters.startDate = startDate;
        if (endDate) filters.endDate = endDate;
        
        // Pagination
        if (limit) {
            filters.limit = parseInt(limit);
            if (page) {
                filters.offset = (parseInt(page) - 1) * filters.limit;
            }
        }
        
        const transactions = await Transaction.findByUserId(userId, filters);
        
        // Get statistics
        const stats = await Transaction.getStats(
            userId, 
            startDate || '2000-01-01', 
            endDate || '2100-12-31'
        );
        
        res.json({
            success: true,
            count: transactions.length,
            stats,
            transactions
        });
        
    } catch (error) {
        console.error('Get transactions error:', error);
        res.status(500).json({ 
            success: false,
            error: 'Failed to fetch transactions' 
        });
    }
};

// Get single transaction
exports.getTransaction = async (req, res) => {
    try {
        const userId = req.userId;
        const transactionId = req.params.id;
        
        const transaction = await Transaction.findById(transactionId);
        
        if (!transaction) {
            return res.status(404).json({ 
                success: false,
                error: 'Transaction not found' 
            });
        }
        
        if (transaction.user_id !== userId) {
            return res.status(403).json({ 
                success: false,
                error: 'Access denied' 
            });
        }
        
        res.json({
            success: true,
            transaction
        });
        
    } catch (error) {
        console.error('Get transaction error:', error);
        res.status(500).json({ 
            success: false,
            error: 'Failed to fetch transaction' 
        });
    }
};

// Create new transaction
exports.createTransaction = async (req, res) => {
    try {
        const userId = req.userId;
        const { category_id, amount, description, type, date } = req.body;
        
        // Validate required fields
        if (!amount || !type) {
            return res.status(400).json({ 
                success: false,
                error: 'Amount and type are required' 
            });
        }
        
        if (isNaN(parseFloat(amount)) || parseFloat(amount) <= 0) {
            return res.status(400).json({ 
                success: false,
                error: 'Amount must be a positive number' 
            });
        }
        
        if (!['income', 'expense'].includes(type)) {
            return res.status(400).json({ 
                success: false,
                error: 'Type must be either income or expense' 
            });
        }
        
        const transactionData = {
            user_id: userId,
            category_id: category_id || null,
            amount: parseFloat(amount),
            description: description || '',
            type,
            date: date || new Date().toISOString().split('T')[0]
        };
        
        const transaction = await Transaction.create(transactionData);
        
        res.status(201).json({
            success: true,
            message: 'Transaction created successfully',
            transaction
        });
        
    } catch (error) {
        console.error('Create transaction error:', error);
        res.status(500).json({ 
            success: false,
            error: 'Failed to create transaction' 
        });
    }
};

// Update transaction
exports.updateTransaction = async (req, res) => {
    try {
        const userId = req.userId;
        const transactionId = req.params.id;
        const updates = req.body;
        
        // First check if transaction exists and belongs to user
        const existingTransaction = await Transaction.findById(transactionId);
        
        if (!existingTransaction) {
            return res.status(404).json({ 
                success: false,
                error: 'Transaction not found' 
            });
        }
        
        if (existingTransaction.user_id !== userId) {
            return res.status(403).json({ 
                success: false,
                error: 'Access denied' 
            });
        }
        
        // Validate amount if provided
        if (updates.amount !== undefined) {
            if (isNaN(parseFloat(updates.amount)) || parseFloat(updates.amount) <= 0) {
                return res.status(400).json({ 
                    success: false,
                    error: 'Amount must be a positive number' 
                });
            }
            updates.amount = parseFloat(updates.amount);
        }
        
        // Validate type if provided
        if (updates.type && !['income', 'expense'].includes(updates.type)) {
            return res.status(400).json({ 
                success: false,
                error: 'Type must be either income or expense' 
            });
        }
        
        const updatedTransaction = await Transaction.update(transactionId, updates);
        
        res.json({
            success: true,
            message: 'Transaction updated successfully',
            transaction: updatedTransaction
        });
        
    } catch (error) {
        console.error('Update transaction error:', error);
        res.status(500).json({ 
            success: false,
            error: 'Failed to update transaction' 
        });
    }
};

// Delete transaction
exports.deleteTransaction = async (req, res) => {
    try {
        const userId = req.userId;
        const transactionId = req.params.id;
        
        const deleted = await Transaction.delete(transactionId, userId);
        
        if (!deleted) {
            return res.status(404).json({ 
                success: false,
                error: 'Transaction not found or access denied' 
            });
        }
        
        res.json({
            success: true,
            message: 'Transaction deleted successfully'
        });
        
    } catch (error) {
        console.error('Delete transaction error:', error);
        res.status(500).json({ 
            success: false,
            error: 'Failed to delete transaction' 
        });
    }
};

// Get transaction statistics
exports.getTransactionStats = async (req, res) => {
    try {
        const userId = req.userId;
        const { startDate, endDate } = req.query;
        
        // Default to current month if no dates provided
        const now = new Date();
        const defaultStart = new Date(now.getFullYear(), now.getMonth(), 1).toISOString().split('T')[0];
        const defaultEnd = new Date(now.getFullYear(), now.getMonth() + 1, 0).toISOString().split('T')[0];
        
        const stats = await Transaction.getStats(
            userId, 
            startDate || defaultStart, 
            endDate || defaultEnd
        );
        
        const categoryStats = await Transaction.getCategoryStats(
            userId,
            startDate || defaultStart,
            endDate || defaultEnd
        );
        
        res.json({
            success: true,
            period: {
                startDate: startDate || defaultStart,
                endDate: endDate || defaultEnd
            },
            stats,
            categoryStats
        });
        
    } catch (error) {
        console.error('Get stats error:', error);
        res.status(500).json({ 
            success: false,
            error: 'Failed to fetch statistics' 
        });
    }
};


// Add this function to transactionController.js
exports.getDashboardData = async (req, res) => {
  try {
    console.log('🚀 getDashboardData called');
    console.log(' req.userId:', req.userId, 'type:', typeof req.userId);
    
    const userId = parseInt(req.userId);
    
    // Get current date for calculations
    const now = new Date();
    const currentMonth = now.getMonth() + 1;
    const currentYear = now.getFullYear();
    
    // Calculate start and end dates for current month
    const startOfMonth = new Date(currentYear, currentMonth - 1, 1)
      .toISOString().split('T')[0];
    const endOfMonth = new Date(currentYear, currentMonth, 0)
      .toISOString().split('T')[0];
    
    // Calculate start and end dates for previous month
    const startOfPrevMonth = new Date(currentYear, currentMonth - 2, 1)
      .toISOString().split('T')[0];
    const endOfPrevMonth = new Date(currentYear, currentMonth - 1, 0)
      .toISOString().split('T')[0];
    
    console.log(' Date range:', { startOfMonth, endOfMonth });
    
    // Get current month transactions
    const currentMonthFilters = {
      startDate: startOfMonth,
      endDate: endOfMonth
    };
    
    const currentMonthTransactions = await Transaction.findByUserId(userId, currentMonthFilters);
    
    // Get previous month transactions
    const prevMonthFilters = {
      startDate: startOfPrevMonth,
      endDate: endOfPrevMonth
    };
    
    const prevMonthTransactions = await Transaction.findByUserId(userId, prevMonthFilters);
    
    // Calculate totals
    const totalIncome = currentMonthTransactions
      .filter(t => t.type === 'income')
      .reduce((sum, t) => sum + parseFloat(t.amount), 0);
    
    const totalExpense = currentMonthTransactions
      .filter(t => t.type === 'expense')
      .reduce((sum, t) => sum + parseFloat(t.amount), 0);
    
    const totalBalance = totalIncome - totalExpense;
    
    // Calculate percentage change from previous month
    const prevMonthIncome = prevMonthTransactions
      .filter(t => t.type === 'income')
      .reduce((sum, t) => sum + parseFloat(t.amount), 0);
    
    const prevMonthExpense = prevMonthTransactions
      .filter(t => t.type === 'expense')
      .reduce((sum, t) => sum + parseFloat(t.amount), 0);
    
    const prevMonthBalance = prevMonthIncome - prevMonthExpense;
    
    let percentageChange = 0;
    if (prevMonthBalance !== 0) {
      percentageChange = ((totalBalance - prevMonthBalance) / Math.abs(prevMonthBalance)) * 100;
    } else if (totalBalance !== 0) {
      percentageChange = 100; // Infinite growth from zero
    }
    
    // Get recent transactions (last 5)
    const recentTransactions = currentMonthTransactions
      .sort((a, b) => new Date(b.date) - new Date(a.date))
      .slice(0, 5)
      .map(t => ({
        name: t.description || `Transaction #${t.id}`,
        date: t.date,
        amount: t.type === 'income' ? parseFloat(t.amount) : -parseFloat(t.amount)
      }));
    
    res.json({
      success: true,
      data: {
        totalBalance: totalBalance.toFixed(2),
        totalIncome: totalIncome.toFixed(2),
        totalExpense: totalExpense.toFixed(2),
        percentageChange: percentageChange.toFixed(0),
        recentTransactions,
        currency: "USD"
      }
    });
    
  } catch (error) {
    console.error('❌ getDashboardData FULL ERROR:', error);
    // Return fallback data
    res.json({
      success: true,
      data: {
        totalBalance: "0.00",
        totalIncome: "0.00",
        totalExpense: "0.00",
        percentageChange: "0",
        recentTransactions: [],
        currency: "USD"
      }
    });
  }
};


