const User = require('../models/user');
const jwt = require('jsonwebtoken');
const { validationResult } = require('express-validator');

// Generate JWT Token
const generateToken = (userId) => {
  return jwt.sign(
    { userId },
    process.env.JWT_SECRET || 'your-secret-key-change-in-production',
    { expiresIn: '7d' }
  );
};

// Register new user
exports.register = async (req, res) => {
    try {
        const { username, email, password } = req.body;
        
        // Check if user already exists
        const existingUser = await User.findByEmail(email);
        if (existingUser) {
            return res.status(400).json({
                error: 'User already exists with this email'
            });
        }
        
        // Create new user
        const user = await User.create({ username, email, password });
        
        // Generate token
        const token = generateToken(user.id);
        
        // Return response
        res.status(201).json({
            success: true,
            message: 'User registered successfully',
            user: {
                id: user.id,
                email: user.email,
                username: user.username
            },
            token
        });
        
    } catch (error) {
        console.error('Registration error:', error);
        res.status(500).json({
            error: 'Registration failed',
            message: error.message
        });
    }
};


// Login user
exports.login = async (req, res) => {
    try {
        const { email, username, password } = req.body;
        
        // Find user by email OR username
        let user;
        if (email.includes('@')) {
            // It's an email
            user = await User.findByEmail(email);
        } else if (username) {
            // It's a username
            user = await User.findByUsername(username);
        }
        
        if (!user) {
            return res.status(401).json({
                error: 'Invalid username/email or password'
            });
        }
        
        // Check password
        const isPasswordValid = await User.comparePassword(password, user.password);
        if (!isPasswordValid) {
            return res.status(401).json({
                error: 'Invalid credentials'
            });
        }
        
        // Generate token
        const token = generateToken(user.id);
        
        // Return response WITHOUT sensitive data
        res.json({
            success: true,
            message: 'Login successful',
            user: {
                id: user.id,
                username: user.username,
                email: user.email
                // Don't include created_at if it doesn't exist
            },
            token
        });
        
    } catch (error) {
        console.error('Login error:', error);
        res.status(500).json({
            error: 'Login failed',
            message: error.message
        });
    }
};


// Get user profile
exports.getProfile = async (req, res) => {
  try {
    const user = await User.findById(req.userId);
    if (!user) {
      return res.status(404).json({ 
        error: 'User not found' 
      });
    }

    res.json({
      success: true,
      user
    });
  } catch (error) {
    console.error('Profile error:', error);
    res.status(500).json({ 
      error: 'Failed to fetch profile',
      message: error.message 
    });
  }
};

// Update user profile
exports.updateProfile = async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const user = await User.update(req.userId, req.body);
    if (!user) {
      return res.status(404).json({ 
        error: 'User not found' 
      });
    }

    res.json({
      success: true,
      message: 'Profile updated successfully',
      user
    });
  } catch (error) {
    console.error('Update profile error:', error);
    res.status(500).json({ 
      error: 'Failed to update profile',
      message: error.message 
    });
  }
};

// Forgot password (simplified - would send email in production)
exports.forgotPassword = async (req, res) => {
  try {
    const { email } = req.body;
    
    // Check if user exists
    const user = await User.findByEmail(email);
    if (!user) {
      // For security, don't reveal if user exists
      return res.json({
        success: true,
        message: 'If an account exists with this email, password reset instructions have been sent'
      });
    }

    // In production: Generate reset token, save to DB, send email
    const resetToken = jwt.sign(
      { userId: user.id, type: 'password_reset' },
      process.env.JWT_SECRET || 'your-secret-key-change-in-production',
      { expiresIn: '1h' }
    );

    // For demo purposes only - in production, send email
    res.json({
      success: true,
      message: 'Password reset instructions sent to your email',
      demoResetLink: `http://localhost:5000/api/auth/reset-password?token=${resetToken}`,
      note: 'In production, this would be sent via email'
    });
  } catch (error) {
    console.error('Forgot password error:', error);
    res.status(500).json({ 
      error: 'Failed to process request',
      message: error.message 
    });
  }
};

// Reset password
exports.resetPassword = async (req, res) => {
  try {
    const { token, newPassword } = req.body;
    
    // Verify token
    const decoded = jwt.verify(
      token, 
      process.env.JWT_SECRET || 'your-secret-key-change-in-production'
    );
    
    if (decoded.type !== 'password_reset') {
      return res.status(400).json({ 
        error: 'Invalid reset token' 
      });
    }

    // Update password
    await User.update(decoded.userId, { password: newPassword });

    res.json({
      success: true,
      message: 'Password reset successful. You can now login with your new password.'
    });
  } catch (error) {
    console.error('Reset password error:', error);
    
    if (error.name === 'TokenExpiredError') {
      return res.status(400).json({ 
        error: 'Reset token has expired' 
      });
    }
    
    if (error.name === 'JsonWebTokenError') {
      return res.status(400).json({ 
        error: 'Invalid reset token' 
      });
    }
    
    res.status(500).json({ 
      error: 'Failed to reset password',
      message: error.message 
    });
  }
};
