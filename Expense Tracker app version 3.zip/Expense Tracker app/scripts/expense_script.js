const API_URL = 'http://localhost:5000/api';
let authToken = localStorage.getItem('authToken');

// DOM Elements
const resetBtn = document.getElementById('reset');
const quitBtn = document.getElementById('quit');
const viewAllBtn = document.getElementById('view');
const totalAmountElement = document.getElementById('totalAmount');
const categoryItems = document.querySelectorAll('.category-item');
const dateInput = document.getElementById('dateInput');
const amountInput = document.getElementById('amountInput');
const descriptionInput = document.getElementById('description');
const saveButton = document.getElementById('saveButton');

// State
let selectedCategory = 'food';
let selectedDate = new Date().toISOString().split('T')[0];
let description = '';
let totalAmount = 0.00;

// Initialize the form
async function initializeForm() {
    // Check authentication
    if (!authToken) {
        alert('Please login first');
        window.location.href = 'login.html';
        return;
    }

    // Set today's date
    const today = new Date();
    const formattedToday = today.toISOString().split('T')[0];
    dateInput.value = formattedToday;
    selectedDate = formattedToday;

    // Load categories from backend
    await loadCategoriesFromBackend();

    // Set initial total amount
    updateTotalAmount(0.00);

    // Add event listeners
    setupEventListeners();
}

// Load categories from backend
async function loadCategoriesFromBackend() {
    try {
        const response = await fetch(`${API_URL}/categories`, {
            headers: {
                'Authorization': `Bearer ${authToken}`
            }
        });

        const data = await response.json();
        
        if (response.ok && data.categories && data.categories.length > 0) {
            // Update category items with data from backend
            updateCategoryUI(data.categories);
        } else {
            console.log('No categories found or error loading categories');
        }
    } catch (error) {
        console.error('Error loading categories:', error);
    }
}

// Update category UI with data from backend
function updateCategoryUI(categories) {
    const categoriesContainer = document.querySelector('.categories');
    categoriesContainer.innerHTML = '';
    
    // Show only first 4 categories
    const categoriesToShow = categories.slice(0, 4);
    
    categoriesToShow.forEach(category => {
        const categoryItem = document.createElement('div');
        categoryItem.className = `category-item ${category.icon || 'other'}`;
        categoryItem.setAttribute('data-category', category.id);
        categoryItem.setAttribute('data-name', category.name);
        categoryItem.textContent = category.name;
        
        categoriesContainer.appendChild(categoryItem);
    });
    
    // Add "View All" functionality
    if (categories.length > 4) {
        viewAllBtn.style.display = 'block';
        viewAllBtn.addEventListener('click', () => {
            showAllCategoriesModal(categories);
        });
    }
}

// Show all categories in a modal
function showAllCategoriesModal(categories) {
    const modal = document.createElement('div');
    modal.className = 'modal-overlay';
    modal.innerHTML = `
        <div class="modal-content">
            <div class="modal-header">
                <h3>Select Category</h3>
                <span class="close-modal">&times;</span>
            </div>
            <div class="modal-categories">
                ${categories.map(cat => `
                    <div class="modal-category-item ${cat.icon || 'other'}" 
                         data-category="${cat.id}"
                         data-name="${cat.name}">
                        ${cat.name}
                    </div>
                `).join('')}
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    
    // Add event listeners
    modal.querySelector('.close-modal').addEventListener('click', () => {
        document.body.removeChild(modal);
    });
    
    modal.querySelectorAll('.modal-category-item').forEach(item => {
        item.addEventListener('click', () => {
            const categoryId = item.getAttribute('data-category');
            const categoryName = item.getAttribute('data-name');
            
            // Update selected category
            selectedCategory = categoryId;
            
            // Update UI to show selected category
            document.querySelectorAll('.category-item').forEach(cat => {
                cat.classList.remove('selected');
                if (cat.getAttribute('data-category') === categoryId) {
                    cat.classList.add('selected');
                }
            });
            
            document.body.removeChild(modal);
        });
    });
    
    // Close modal when clicking outside
    modal.addEventListener('click', (e) => {
        if (e.target === modal) {
            document.body.removeChild(modal);
        }
    });
}

// Set up all event listeners
function setupEventListeners() {
    // Category selection
    document.addEventListener('click', (e) => {
        if (e.target.classList.contains('category-item')) {
            // Remove selected class from all categories
            categoryItems.forEach(cat => cat.classList.remove('selected'));
            
            // Add selected class to clicked category
            e.target.classList.add('selected');
            
            // Update selected category
            selectedCategory = e.target.getAttribute('data-category');
        }
    });

    // Date input
    dateInput.addEventListener('change', () => {
        selectedDate = dateInput.value;
    });

    // Amount input
    amountInput.addEventListener('input', () => {
        const amount = parseFloat(amountInput.value) || 0;
        updateTotalAmount(amount);
    });

    // Description input
    descriptionInput.addEventListener('input', () => {
        description = descriptionInput.value;
    });

    // Save button click
    saveButton.addEventListener('click', saveExpenseToBackend);

    // Reset button
    resetBtn.addEventListener('click', resetForm);

    // Quit button (close page)
    quitBtn.addEventListener('click', () => {
        if (confirm('Are you sure you want to quit? Unsaved changes will be lost.')) {
            window.location.href = 'dashboard.html'; // or wherever you want to go
        }
    });

    // Total amount click (for quick edit)
    totalAmountElement.addEventListener('click', () => {
        const newAmount = prompt('Enter new amount:', totalAmount.toFixed(2));
        if (newAmount !== null && !isNaN(parseFloat(newAmount))) {
            const amount = parseFloat(newAmount);
            updateTotalAmount(amount);
            amountInput.value = amount.toFixed(2);
        }
    });
}

// Update total amount display
function updateTotalAmount(amount) {
    totalAmount = amount;
    totalAmountElement.textContent = amount.toFixed(2);
}

// Save expense to backend
async function saveExpenseToBackend() {
    // Validate form
    if (totalAmount <= 0) {
        alert('Please enter a valid expense amount.');
        amountInput.focus();
        return;
    }

    if (!description.trim()) {
        alert('Please enter a description for the expense.');
        descriptionInput.focus();
        return;
    }

    if (!selectedCategory) {
        alert('Please select a category.');
        return;
    }

    // Create expense object
    const expense = {
        amount: totalAmount,
        category_id: parseInt(selectedCategory),
        date: selectedDate,
        description: description.trim(),
        type: 'expense',
        currency: 'FCFA'
    };

    console.log('Saving expense:', expense);

    // Show loading state
    saveButton.classList.add('loading');
    saveButton.textContent = 'Saving...';

    try {
        const response = await fetch(`${API_URL}/transactions`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${authToken}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(expense)
        });

        const data = await response.json();

        if (response.ok) {
            console.log('✅ Expense saved successfully:', data);
            
            // Update category spent amount in the backend
            await updateCategorySpentAmount(selectedCategory, totalAmount);
            
            alert(`Expense of ${totalAmount.toFixed(2)}FCFA saved successfully!`);
            
            // Reset form
            resetForm();
            
            // Optionally redirect to dashboard
            // window.location.href = 'dashboard.html';
            
        } else {
            console.error('❌ Save failed:', data.error);
            alert('Failed to save expense: ' + (data.error || 'Unknown error'));
        }
    } catch (error) {
        console.error('❌ Network error:', error);
        alert('Network error - check if backend is running');
    } finally {
        // Reset button state
        saveButton.classList.remove('loading');
        saveButton.textContent = 'Save Expense';
    }
}

// Update category spent amount in backend
async function updateCategorySpentAmount(categoryId, amount) {
    try {
        // First, get current category to check current spent amount
        const response = await fetch(`${API_URL}/categories/${categoryId}`, {
            headers: {
                'Authorization': `Bearer ${authToken}`
            }
        });

        const data = await response.json();
        
        if (response.ok && data.category) {
            const currentSpent = data.category.spent || 0;
            const newSpent = currentSpent + amount;
            
            // Update category with new spent amount
            const updateResponse = await fetch(`${API_URL}/categories/${categoryId}`, {
                method: 'PUT',
                headers: {
                    'Authorization': `Bearer ${authToken}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    spent: newSpent
                })
            });
            
            if (updateResponse.ok) {
                console.log('✅ Category spent amount updated');
            }
        }
    } catch (error) {
        console.error('Error updating category spent:', error);
    }
}

// Reset form to initial state
function resetForm() {
    // Reset inputs
    amountInput.value = '';
    descriptionInput.value = '';
    
    // Reset date to today
    const today = new Date();
    const formattedToday = today.toISOString().split('T')[0];
    dateInput.value = formattedToday;
    selectedDate = formattedToday;
    
    // Reset amount display
    updateTotalAmount(0.00);
    
    // Reset category selection
    categoryItems.forEach(cat => cat.classList.remove('selected'));
    if (categoryItems.length > 0) {
        categoryItems[0].classList.add('selected');
        selectedCategory = categoryItems[0].getAttribute('data-category');
    }
    
    // Reset description
    description = '';
    
    // Focus on amount input
    amountInput.focus();
}

// Initialize the form when page loads
document.addEventListener('DOMContentLoaded', initializeForm);

// Add modal styles dynamically
const style = document.createElement('style');
style.textContent = `
    .modal-overlay {
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background-color: rgba(0, 0, 0, 0.5);
        display: flex;
        justify-content: center;
        align-items: center;
        z-index: 1000;
    }
    
    .modal-content {
        background-color: white;
        border-radius: 12px;
        padding: 20px;
        width: 90%;
        max-width: 500px;
        max-height: 80vh;
        overflow-y: auto;
    }
    
    .modal-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 20px;
        padding-bottom: 10px;
        border-bottom: 1px solid #e9ecef;
    }
    
    .modal-header h3 {
        margin: 0;
        color: #2d3436;
    }
    
    .close-modal {
        font-size: 24px;
        cursor: pointer;
        color: #636e72;
        transition: color 0.2s ease;
    }
    
    .close-modal:hover {
        color: #2d3436;
    }
    
    .modal-categories {
        display: grid;
        grid-template-columns: repeat(2, 1fr);
        gap: 10px;
    }
    
    .modal-category-item {
        padding: 15px;
        border: 2px solid #e9ecef;
        border-radius: 8px;
        text-align: center;
        cursor: pointer;
        transition: all 0.2s ease;
    }
    
    .modal-category-item:hover {
        background-color: #f8f9fa;
        transform: translateY(-2px);
    }
    
    .modal-category-item.selected {
        border-color: #6c5ce7;
        background-color: #f3f1ff;
    }
`;
document.head.appendChild(style);
