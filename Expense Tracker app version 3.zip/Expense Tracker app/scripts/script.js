const API_URL = 'http://localhost:5000/api';

// Elements
const transactionList = document.getElementById("transactionList");
const totalBalanceEl = document.getElementById("totalBalance");
const incomeEl = document.getElementById("incomeAmount");
const expenseEl = document.getElementById("expenseAmount");
const percentageEl = document.getElementById("percentage");
const analyticsOutput = document.getElementById("analyticsOutput");
const tabs = document.querySelectorAll(".tab");

// Get auth token
const authToken = localStorage.getItem('authToken');

// Check authentication on page load
if (!authToken) {
    alert('Please login first');
    window.location.href = 'login.html';
}

// Load dashboard data from backend
async function loadDashboardData() {
    try {
        const response = await fetch(`${API_URL}/transactions/dashboard`, {
            headers: {
                'Authorization': `Bearer ${authToken}`
            }
        });
        
        if (!response.ok) {
            if (response.status === 401) {
                // Token expired or invalid
                localStorage.removeItem('authToken');
                window.location.href = 'login.html';
                return;
            }
            throw new Error('Failed to load dashboard data');
        }
        
        const result = await response.json();
        
        if (result.success) {
            updateDashboardUI(result.data);
        } else {
            console.error('Backend error:', result.error);
            showFallbackData();
        }
        
    } catch (error) {
        console.error('Error loading dashboard:', error);
        showFallbackData();
    }
}

// Update UI with real data from backend
function updateDashboardUI(data) {
    // Update balance and stats
    totalBalanceEl.textContent = `$${parseFloat(data.totalBalance).toFixed(2)}`;
    incomeEl.textContent = `$${parseFloat(data.totalIncome).toFixed(2)}`;
    expenseEl.textContent = `$${parseFloat(data.totalExpense).toFixed(2)}`;
    percentageEl.textContent = `${data.percentageChange}% this month`;
    
    // Update recent transactions
    renderTransactions(data.recentTransactions);
    
    // Initialize analytics with week view
    updateAnalytics('week');
}

// Fallback to sample data if backend fails
function showFallbackData() {
    console.log('Using fallback data');
    const fallbackData = {
        totalBalance: '0.00',
        totalIncome: '0.00',
        totalExpense: '0.00',
        percentageChange: '0',
        recentTransactions: []
    };
    updateDashboardUI(fallbackData);
    analyticsOutput.textContent = 'Connect to backend to see analytics';
}

// Render transactions to table
function renderTransactions(transactions) {
    transactionList.innerHTML = "";
    
    if (!transactions || transactions.length === 0) {
        const row = document.createElement("tr");
        row.innerHTML = `<td colspan="3" style="text-align: center; color: #999;">No transactions yet</td>`;
        transactionList.appendChild(row);
        return;
    }
    
    transactions.forEach(t => {
        const row = document.createElement("tr");
        row.innerHTML = `
            <td>${t.name}</td>
            <td>${t.date}</td>
            <td class="${t.amount > 0 ? "positive" : "negative"}">
                ${t.amount > 0 ? "+" : ""}$${Math.abs(t.amount).toFixed(2)}
            </td>
        `;
        transactionList.appendChild(row);
    });
}

// Update analytics (you'll need to create more backend endpoints for this)
function updateAnalytics(range) {
    // For now, just show a message
    analyticsOutput.innerHTML = `
        <div style="text-align: center; padding: 40px;">
            <h3 style="color: #666; margin-bottom: 10px;">${range.toUpperCase()} Analytics</h3>
            <p style="color: #999;">Analytics feature coming soon!</p>
            <p style="color: #999; font-size: 14px; margin-top: 20px;">
                Connect to backend to see detailed analytics
            </p>
        </div>
    `;
}

// Add event listeners for tabs
tabs.forEach(tab => {
    tab.addEventListener("click", () => {
        tabs.forEach(t => t.classList.remove("active"));
        tab.classList.add("active");
        const range = tab.dataset.range;
        updateAnalytics(range);
    });
});

// Load dashboard data when page loads
document.addEventListener('DOMContentLoaded', loadDashboardData);

// Optional: Auto-refresh data every 30 seconds
//setInterval(loadDashboardData, 30000);
