// routes/transactionRoutes.js
const express = require('express');
const router = express.Router();
const transactionController = require('../controllers/transactionController');
const authMiddleware = require('../authMiddleware');

// Add this route ABOVE the router.use(authMiddleware.authenticate) line:
router.get('/dashboard', authMiddleware.authenticate, transactionController.getDashboardData);

// All routes require authentication
router.use(authMiddleware.authenticate);
// GET /api/transactions - Get all transactions
router.get('/', transactionController.getTransactions);


// GET /api/transactions/stats - Get statistics
router.get('/stats', transactionController.getTransactionStats);

// GET /api/transactions/:id - Get single transaction
router.get('/:id', transactionController.getTransaction);

// POST /api/transactions - Create transaction
router.post('/', transactionController.createTransaction);

// PUT /api/transactions/:id - Update transaction
router.put('/:id', transactionController.updateTransaction);

// DELETE /api/transactions/:id - Delete transaction
router.delete('/:id', transactionController.deleteTransaction);

module.exports = router;
