// models/Transaction.js
const { pool } = require('../database');

class Transaction {
    // Create new transaction
    static async create(transactionData) {
        const { user_id, category_id, amount, description, type, date } = transactionData;
        
        const [result] = await pool.execute(
            `INSERT INTO transactions (user_id, category_id, amount, description, type, date) 
             VALUES (?, ?, ?, ?, ?, ?)`,
            [user_id, category_id, amount, description || null, type, date || new Date().toISOString().split('T')[0]]
        );
        
        return this.findById(result.insertId);
    }
    
    // Find by ID
    static async findById(id) {
        const [rows] = await pool.execute(
            `SELECT t.*, c.name as category_name, c.color as category_color 
             FROM transactions t 
             LEFT JOIN categories c ON t.category_id = c.id 
             WHERE t.id = ?`,
            [id]
        );
        return rows[0] || null;
    }
    
    // Get all transactions for user
    static async findByUserId(userId, filters = {}) {
        let query = `
            SELECT t.*, c.name as category_name, c.color as category_color, c.icon as category_icon 
            FROM transactions t 
            LEFT JOIN categories c ON t.category_id = c.id 
            WHERE t.user_id = ?
        `;
        
        const params = [userId];
        
        // Apply filters
        if (filters.type) {
            query += ' AND t.type = ?';
            params.push(filters.type);
        }
        
        if (filters.category_id) {
            query += ' AND t.category_id = ?';
            params.push(filters.category_id);
        }
        
        if (filters.startDate) {
            query += ' AND t.date >= ?';
            params.push(filters.startDate);
        }
        
        if (filters.endDate) {
            query += ' AND t.date <= ?';
            params.push(filters.endDate);
        }
        
        // Sorting
        query += ' ORDER BY t.date DESC, t.created_at DESC';
        
        // Limit/Offset for pagination
        if (filters.limit) {
            query += ' LIMIT ?';
            params.push(filters.limit);
        }
        
        if (filters.offset) {
            query += ' OFFSET ?';
            params.push(filters.offset);
        }


        
        const [rows] = await pool.execute(query, params);
        return rows;
    }
    
    // Update transaction
    static async update(id, updates) {
        const { category_id, amount, description, type, date } = updates;
        
        const fields = [];
        const values = [];
        
        if (category_id !== undefined) {
            fields.push('category_id = ?');
            values.push(category_id);
        }
        
        if (amount !== undefined) {
            fields.push('amount = ?');
            values.push(amount);
        }
        
        if (description !== undefined) {
            fields.push('description = ?');
            values.push(description);
        }
        
        if (type !== undefined) {
            fields.push('type = ?');
            values.push(type);
        }
        
        if (date !== undefined) {
            fields.push('date = ?');
            values.push(date);
        }
        
        if (fields.length === 0) {
            return this.findById(id);
        }
        
        values.push(id);
        
        await pool.execute(
            `UPDATE transactions SET ${fields.join(', ')} WHERE id = ?`,
            values
        );
        
        return this.findById(id);
    }
    
    // Delete transaction
    static async delete(id, userId) {
        const [result] = await pool.execute(
            'DELETE FROM transactions WHERE id = ? AND user_id = ?',
            [id, userId]
        );
        return result.affectedRows > 0;
    }
    
    // Get transaction statistics
    static async getStats(userId, startDate, endDate) {
        const [rows] = await pool.execute(
            `SELECT 
                COUNT(*) as total_transactions,
                SUM(CASE WHEN type = 'income' THEN amount ELSE 0 END) as total_income,
                SUM(CASE WHEN type = 'expense' THEN amount ELSE 0 END) as total_expense,
                (SUM(CASE WHEN type = 'income' THEN amount ELSE 0 END) - 
                 SUM(CASE WHEN type = 'expense' THEN amount ELSE 0 END)) as net_balance
             FROM transactions 
             WHERE user_id = ? AND date BETWEEN ? AND ?`,
            [userId, startDate, endDate]
        );
        
        return rows[0] || {
            total_transactions: 0,
            total_income: 0,
            total_expense: 0,
            net_balance: 0
        };
    }
    
    // Get category-wise spending
    static async getCategoryStats(userId, startDate, endDate) {
        const [rows] = await pool.execute(
            `SELECT 
                c.name as category_name,
                c.color as category_color,
                c.icon as category_icon,
                COUNT(t.id) as transaction_count,
                SUM(t.amount) as total_amount
             FROM categories c
             LEFT JOIN transactions t ON c.id = t.category_id 
                AND t.user_id = ? 
                AND t.type = 'expense'
                AND t.date BETWEEN ? AND ?
             WHERE c.user_id = ? OR c.user_id = 0
             GROUP BY c.id
             ORDER BY total_amount DESC`,
            [userId, startDate, endDate, userId]
        );
        
        return rows;
    }
}

module.exports = Transaction;
