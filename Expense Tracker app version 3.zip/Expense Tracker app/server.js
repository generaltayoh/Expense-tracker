// server.js - UPDATED VERSION
const express = require('express');
const cors = require('cors');
require('dotenv').config();

const { testConnection } = require('./database');

// Import routes
const authRoutes = require('./routes/authRoutes');
const categoryRoutes = require('./routes/categoryRoutes');
const transactionRoutes = require('./routes/transactionRoutes'); // ADD THIS

const app = express();

// Middleware
app.use(cors({
    origin: ['http://localhost:5500', 'http://127.0.0.1:5500', 'http://localhost:3000'],
    credentials: true
}));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Test database connection on startup
testConnection().then(() => {
    console.log('📊 Database ready for use');
}).catch(err => {
    console.log('⚠️  Database connection issue (continuing anyway)');
});

// Routes
app.use('/api/auth', authRoutes);
app.use('/api/categories', categoryRoutes);
app.use('/api/transactions', transactionRoutes); // ADD THIS

// Health check
app.get('/api/health', (req, res) => {
    res.json({ 
        status: 'OK', 
        message: 'Expense Tracker API is running',
        timestamp: new Date().toISOString(),
        endpoints: {
            auth: '/api/auth',
            categories: '/api/categories',
            transactions: '/api/transactions'
        }
    });
});

// Error handling
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).json({ 
        error: 'Something went wrong!',
        message: process.env.NODE_ENV === 'development' ? err.message : undefined
    });
});

const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {
    console.log(`
    ╔═══════════════════════════════════════════╗
    ║      EXPENSE TRACKER BACKEND RUNNING      ║
    ╚═══════════════════════════════════════════╝
    📍 Port: ${PORT}
    🌐 Health: http://localhost:${PORT}/api/health
    📊 Database: ${process.env.DB_NAME || 'master_your_money'}
    
    🚀 Available APIs:
       POST   /api/auth/register
       POST   /api/auth/login
       GET    /api/categories
       POST   /api/categories
       GET    /api/transactions
       POST   /api/transactions
    `);
});
