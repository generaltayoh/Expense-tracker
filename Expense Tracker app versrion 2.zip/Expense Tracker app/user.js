const { pool } = require('./database');
const bcrypt = require('bcryptjs');

class User {
  // Create new user
  static async create(userData) {
    const { username, email, password } = userData;
    
    // Hash password
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);
    
    const [result] = await pool.execute(
      'INSERT INTO users (username, email, password) VALUES (?, ?, ?)',
      [username || null, email, hashedPassword]
    );
    
    return {
      id: result.insertId,
      username,
      email,
      createdAt: new Date()
    };
  }

  // Find user by email
  static async findByEmail(email) {
    const [rows] = await pool.execute(
      'SELECT id, email, password, created_at FROM users WHERE email = ?',
      [email]
    );
    return rows[0] || null;
  }

  //Find user username
  //static async findByEmail(username) {
    //const [rows] = await pool.execute(
      //'SELECT id, username, email, password, name, created_at FROM users WHERE username = ?',
      //[username]
    //);
    //return rows[0] || null;
  //}

  // Find user by ID
  static async findById(id) {
    const [rows] = await pool.execute(
      'SELECT id, email, created_at FROM users WHERE id = ?',
      [id]
    );
    return rows[0] || null;
  }

  // Compare password
  static async comparePassword(candidatePassword, hashedPassword) {
    return await bcrypt.compare(candidatePassword, hashedPassword);
  }

  // Update user profile
  static async update(id, updateData) {
    const fields = [];
    const values = [];
    
    if (updateData.username) {
      fields.push('username = ?');
      values.push(updateData.username);
    }
    
    if (updateData.email) {
      fields.push('email = ?');
      values.push(updateData.email);
    }
    
    if (updateData.password) {
      const salt = await bcrypt.genSalt(10);
      const hashedPassword = await bcrypt.hash(updateData.password, salt);
      fields.push('password = ?');
      values.push(hashedPassword);
    }
    
    if (fields.length === 0) {
      return null;
    }
    
    values.push(id);
    
    await pool.execute(
      `UPDATE users SET ${fields.join(', ')} WHERE id = ?`,
      values
    );
    
    return this.findById(id);
  }

  // Get all users (for admin purposes)
  static async getAll(limit = 100, offset = 0) {
    const [rows] = await pool.execute(
      'SELECT id, email, username, created_at FROM users LIMIT ? OFFSET ?',
      [limit, offset]
    );
    return rows;
  }
}

module.exports = User;
