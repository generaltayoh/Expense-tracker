
const express = require('express');
const router = express.Router();
const authController = require('./authController');
const authMiddleware = require('./authMiddleware');

// Public routes
router.post('/register', authMiddleware.validateRegistration, authController.register);
router.post('/login', authMiddleware.validateLogin, authController.login);
router.post('/forgot-password', authController.forgotPassword);
router.post('/reset-password', authController.resetPassword);

// Protected routes (require authentication)
router.get('/profile', authMiddleware.authenticate, authController.getProfile);
router.put('/profile', authMiddleware.authenticate, authController.updateProfile);

// Test route
router.get('/test', (req, res) => {
  res.json({ 
    message: 'Auth API is working!',
    endpoints: {
      register: 'POST /api/auth/register',
      login: 'POST /api/auth/login',
      profile: 'GET /api/auth/profile',
      forgotPassword: 'POST /api/auth/forgot-password'
    }
  });
});

module.exports = router;
