const express = require('express');
const router = express.Router();
const categoryController = require('../controllers/categoryController');
const authMiddleware = require('../authMiddleware');

// All routes require authentication
router.use(authMiddleware.authenticate);

// GET /api/categories - Get all categories for user
router.get('/', categoryController.getCategories);

// GET /api/categories/stats - Get category statistics
router.get('/stats', categoryController.getCategoryStats);

// GET /api/categories/init-defaults - Initialize default categories
router.post('/init-defaults', categoryController.initDefaultCategories);

// GET /api/categories/:id - Get single category
router.get('/:id', categoryController.getCategoryById);

// POST /api/categories - Create new category
router.post('/', categoryController.createCategory);

// PUT /api/categories/:id - Update category
router.put('/:id', categoryController.updateCategory);

// DELETE /api/categories/:id - Delete category
router.delete('/:id', categoryController.deleteCategory);

module.exports = router;
