const { pool } = require('../database');
const bcrypt = require('bcryptjs');

class Category {
  // Create new category
  static async create(categoryData) {
    const { user_id, name, type, color, icon, budget, spent } = categoryData;
    
    const [result] = await pool.execute(
      `INSERT INTO categories (user_id, name, type, color, icon, budget, spent) 
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [user_id, name, type || 'expense', color || '#3B82F6', icon || '💰', budget || 0, spent || 0]
    );
    
    return this.findById(result.insertId);
  }

  // Find category by ID
  static async findById(id) {
    const [rows] = await pool.execute(
      'SELECT * FROM categories WHERE id = ?',
      [id]
    );
    return rows[0] || null;
  }

  // Get all categories for a user
  static async findByUserId(userId, type = null) {
    let query = 'SELECT * FROM categories WHERE user_id = ? OR user_id = 0';
    const params = [userId];
    
    if (type) {
      query += ' AND type = ?';
      params.push(type);
    }
    
    query += ' ORDER BY type, name';
    
    const [rows] = await pool.execute(query, params);
    return rows;
  }

  // Update category
  static async update(id, updateData) {
    const { name, type, color, icon, budget, spent } = updateData;
    
    const fields = [];
    const values = [];
    
    if (name) {
      fields.push('name = ?');
      values.push(name);
    }
    
    if (type) {
      fields.push('type = ?');
      values.push(type);
    }
    
    if (color) {
      fields.push('color = ?');
      values.push(color);
    }
    
    if (icon) {
      fields.push('icon = ?');
      values.push(icon);
    }
    
    if (budget !== undefined) {
      fields.push('budget = ?');
      values.push(budget);
    }

    if (spent !== undefined) {
      fields.push('spent = ?');
      values.push(spent);
    }
    
    if (fields.length === 0) {
      return this.findById(id);
    }
    
    values.push(id);
    
    await pool.execute(
      `UPDATE categories SET ${fields.join(', ')} WHERE id = ?`,
      values
    );
    
    return this.findById(id);
  }

  // Delete category
  static async delete(id, userId) {
    const [result] = await pool.execute(
      'DELETE FROM categories WHERE id = ? AND user_id = ?',
      [id, userId]
    );
    return result.affectedRows > 0;
  }

  // Get category usage statistics
  static async getUsageStats(userId, startDate, endDate) {
    const [rows] = await pool.execute(
      `SELECT 
        c.id,
        c.name,
        c.type,
        c.color,
        c.icon,
        c.budget,
        c.spent,
        COUNT(t.id) as transaction_count,
        COALESCE(SUM(t.amount), 0) as total_amount,
        COALESCE(SUM(CASE WHEN t.type = 'expense' THEN t.amount ELSE 0 END), 0) as expense_total,
        COALESCE(SUM(CASE WHEN t.type = 'income' THEN t.amount ELSE 0 END), 0) as income_total
      FROM categories c
      LEFT JOIN transactions t ON c.id = t.category_id 
        AND t.user_id = ? 
        AND t.date BETWEEN ? AND ?
      WHERE c.user_id = ? OR c.user_id = 0
      GROUP BY c.id
      ORDER BY c.type, total_amount DESC`,
      [userId, startDate, endDate, userId]
    );
    
    return rows;
  }

  // Copy default categories for a new user
  static async copyDefaultsForUser(userId) {
    const [defaultCategories] = await pool.execute(
      'SELECT name, type, color, icon, budget, spent FROM categories WHERE user_id = 0'
    );
    
    const categories = [];
    for (const cat of defaultCategories) {
      const [result] = await pool.execute(
        `INSERT INTO categories (user_id, name, type, color, icon, budget, spent) 
         VALUES (?, ?, ?, ?, ?, ?, ?)`,
        [userId, cat.name, cat.type, cat.color, cat.icon, cat.budget, cat.spent]
      );
      categories.push({ ...cat, id: result.insertId });
    }
    
    return categories;
  }

  // Check if category belongs to user
  static async belongsToUser(categoryId, userId) {
    const [rows] = await pool.execute(
      'SELECT id FROM categories WHERE id = ? AND (user_id = ? OR user_id = 0)',
      [categoryId, userId]
    );
    return rows.length > 0;
  }
}

module.exports = Category;
