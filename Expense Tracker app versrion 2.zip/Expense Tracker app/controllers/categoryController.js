
const Category = require('../models/category');

// Get all categories for current user
exports.getCategories = async (req, res) => {
  try {
    const userId = req.userId;
    const { type } = req.query; // optional filter: 'income' or 'expense'
    
    const categories = await Category.findByUserId(userId, type);
    
    res.json({
      success: true,
      count: categories.length,
      categories
    });
  } catch (error) {
    console.error('Get categories error:', error);
    res.status(500).json({ 
      success: false,
      error: 'Failed to fetch categories' 
    });
  }
};

// Get category by ID
exports.getCategoryById = async (req, res) => {
  try {
    const userId = req.userId;
    const categoryId = req.params.id;
    
    const category = await Category.findById(categoryId);
    
    if (!category) {
      return res.status(404).json({ 
        success: false,
        error: 'Category not found' 
      });
    }
    
    // Check if user can access this category
    const canAccess = await Category.belongsToUser(categoryId, userId);
    if (!canAccess) {
      return res.status(403).json({ 
        success: false,
        error: 'Access denied' 
      });
    }
    
    res.json({
      success: true,
      category
    });
  } catch (error) {
    console.error('Get category error:', error);
    res.status(500).json({ 
      success: false,
      error: 'Failed to fetch category' 
    });
  }
};

// Create new category
exports.createCategory = async (req, res) => {
  try {
    const userId = req.userId;
    const { name, type, color, icon, budget, spent } = req.body;
    
    // Validate
    if (!name || name.trim().length === 0) {
      return res.status(400).json({ 
        success: false,
        error: 'Category name is required' 
      });
    }
    
    if (type && !['income', 'expense'].includes(type)) {
      return res.status(400).json({ 
        success: false,
        error: 'Type must be either income or expense' 
      });
    }
    
    const categoryData = {
      user_id: userId,
      name: name.trim(),
      type: type || 'expense',
      color,
      icon,
      budget: budget || 0,
      spent: spent || 0
    };
    
    const category = await Category.create(categoryData);
    
    res.status(201).json({
      success: true,
      message: 'Category created successfully',
      category
    });
  } catch (error) {
    console.error('Create category error:', error);
    
    if (error.code === 'ER_DUP_ENTRY') {
      return res.status(400).json({ 
        success: false,
        error: 'Category with this name already exists' 
      });
    }
    
    res.status(500).json({ 
      success: false,
      error: 'Failed to create category' 
    });
  }
};

// Update category
exports.updateCategory = async (req, res) => {
  try {
    const userId = req.userId;
    const categoryId = req.params.id;
    const updates = req.body;
    
    // Check if category belongs to user
    const canAccess = await Category.belongsToUser(categoryId, userId);
    if (!canAccess) {
      return res.status(403).json({ 
        success: false,
        error: 'Access denied' 
      });
    }
    
    // Don't allow updating default categories (user_id = 0)
    const category = await Category.findById(categoryId);
    if (category.user_id === 0) {
      return res.status(403).json({ 
        success: false,
        error: 'Cannot modify default categories' 
      });
    }
    
    const updatedCategory = await Category.update(categoryId, updates);
    
    res.json({
      success: true,
      message: 'Category updated successfully',
      category: updatedCategory
    });
  } catch (error) {
    console.error('Update category error:', error);
    
    if (error.code === 'ER_DUP_ENTRY') {
      return res.status(400).json({ 
        success: false,
        error: 'Category with this name already exists' 
      });
    }
    
    res.status(500).json({ 
      success: false,
      error: 'Failed to update category' 
    });
  }
};

// Delete category
exports.deleteCategory = async (req, res) => {
  try {
    const userId = req.userId;
    const categoryId = req.params.id;
    
    // Check if category belongs to user
    const category = await Category.findById(categoryId);
    
    if (!category) {
      return res.status(404).json({ 
        success: false,
        error: 'Category not found' 
      });
    }
    
    // Don't allow deleting default categories
    if (category.user_id === 0) {
      return res.status(403).json({ 
        success: false,
        error: 'Cannot delete default categories' 
      });
    }
    
    const deleted = await Category.delete(categoryId, userId);
    
    if (!deleted) {
      return res.status(404).json({ 
        success: false,
        error: 'Category not found or access denied' 
      });
    }
    
    res.json({
      success: true,
      message: 'Category deleted successfully'
    });
  } catch (error) {
    console.error('Delete category error:', error);
    res.status(500).json({ 
      success: false,
      error: 'Failed to delete category' 
    });
  }
};

// Get category statistics
exports.getCategoryStats = async (req, res) => {
  try {
    const userId = req.userId;
    const { startDate, endDate } = req.query;
    
    // Default to current month
    const start = startDate || new Date().toISOString().split('T')[0].slice(0, 7) + '-01';
    const end = endDate || new Date().toISOString().split('T')[0];
    
    const stats = await Category.getUsageStats(userId, start, end);
    
    res.json({
      success: true,
      period: { startDate: start, endDate: end },
      stats
    });
  } catch (error) {
    console.error('Get category stats error:', error);
    res.status(500).json({ 
      success: false,
      error: 'Failed to fetch category statistics' 
    });
  }
};

// Initialize default categories for user
exports.initDefaultCategories = async (req, res) => {
  try {
    const userId = req.userId;
    
    const categories = await Category.copyDefaultsForUser(userId);
    
    res.json({
      success: true,
      message: 'Default categories initialized',
      count: categories.length,
      categories
    });
  } catch (error) {
    console.error('Init default categories error:', error);
    res.status(500).json({ 
      success: false,
      error: 'Failed to initialize default categories' 
    });
  }
};
