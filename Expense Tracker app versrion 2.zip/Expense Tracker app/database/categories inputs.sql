-- Default categories for new users
INSERT INTO categories (user_id, name, type, color, icon) VALUES 
(0, 'Food & Dining', 'expense', '#EF4444', '🍕'),
(0, 'Transportation', 'expense', '#3B82F6', '🚗'),
(0, 'Shopping', 'expense', '#8B5CF6', '🛍️'),
(0, 'Entertainment', 'expense', '#EC4899', '🎬'),
(0, 'Bills & Utilities', 'expense', '#10B981', '💡'),
(0, 'Healthcare', 'expense', '#F59E0B', '🏥'),
(0, 'Education', 'expense', '#6366F1', '📚'),
(0, 'Salary', 'income', '#059669', '💰'),
(0, 'Freelance', 'income', '#7C3AED', '💼'),
(0, 'Investment', 'income', '#0EA5E9', '📈');

-- Transactions table (for reference - optional)
CREATE TABLE IF NOT EXISTS transactions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    category_id INT,
    amount DECIMAL(10, 2) NOT NULL,
    description TEXT,
    type ENUM('income', 'expense') NOT NULL,
    date DATE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE SET NULL,
    INDEX idx_user_date (user_id, date),
    INDEX idx_category (category_id)
);

