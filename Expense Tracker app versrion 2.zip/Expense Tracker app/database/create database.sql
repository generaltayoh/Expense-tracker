CREATE DATABASE IF NOT EXISTS master_your_money;
USE master_your_money;