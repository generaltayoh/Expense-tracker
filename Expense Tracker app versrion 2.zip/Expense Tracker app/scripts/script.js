const API_BASE_URL = "HTTP://localhost:5000/api";

document.addEventListener("DOMContentLoaded", function () {
  // DOM Elements
  const loginBtn = document.getElementById("loginBtn");
  const signupBtn = document.getElementById("signupBtn");
  const loginForm = document.getElementById("loginForm");
  const usernameInput = document.getElementById("username");
  const emailInput = document.getElementById("email");
  const passwordInput = document.getElementById("password");
  const emailError = document.getElementById("emailError");
  const passwordError = document.getElementById("passwordError");
  const submitBtn = document.getElementById("submitBtn");
  const btnText = document.getElementById("btnText");
  const googleLoginBtn = document.getElementById("googleLogin");


const loginData = {
  usernameOrEmail: document.getElementById("email").value,
  password: document.getElementById("password").value,
};



  
  //const successMessage = document.getElementById('successMessage');

  // Toggle between Login and Sign Up
  loginBtn.addEventListener("click", function () {
    loginBtn.classList.add("active");
    signupBtn.classList.remove("active");
    btnText.textContent = "Log In";
    document.querySelector(".login-title").textContent = "Welcome Back";
    document.querySelector(".login-header p").textContent =
      "Log in to continue managing your finances";
  });

  signupBtn.addEventListener("click", function () {
    signupBtn.classList.add("active");
    loginBtn.classList.remove("active");
    btnText.textContent = "Sign Up";
    document.querySelector(".login-title").textContent = "Create Account";
    document.querySelector(".login-header p").textContent =
      "Sign up to start tracking your expenses";
  });
  /////start

  async function registerUser(username, email, password) {
    const response = await fetch(`${API_BASE_URL}/auth/register`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({username, email, password }),
    });

    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.error || "Registration failed");
    }

    // Save token for future requests
    localStorage.setItem("authToken", data.token);

    showMessage("Registration successful!", "success");

    // Simulate redirect
    setTimeout(() => {
      alert("Registration successful! You can now login.");
    }, 2000);
  }

  async function loginUser(email, password, username) {
    const response = await fetch(`${API_BASE_URL}/auth/login`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ email, password, username }),
    });

    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.error || "Login failed");
    }

    // Save token for future requests
    localStorage.setItem("authToken", data.token);

    showMessage("Login successful! Redirecting...", "success");

    // Simulate redirect
    setTimeout(() => {
      alert("Login successful! Welcome to your dashboard.");
    }, 2000);
  }

  async function forgotPassword(email) {
    const response = await fetch(`${API_BASE_URL}/auth/forgot-password`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ email }),
    });

    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.error || "Failed to send reset instructions");
    }

    return data;
  }

  // ===== HELPER FUNCTIONS =====

  function showMessage(message, type = "success") {
    // You need to add these elements to your HTML
    const successMessage = document.getElementById("successMessage");
    const errorMessage = document.getElementById("errorMessage");
    const successText = document.getElementById("successText");
    const errorText = document.getElementById("errorText");

    if (type === "success") {
      successText.textContent = message;
      successMessage.style.display = "block";
      errorMessage.style.display = "none";
    } else {
      errorText.textContent = message;
      errorMessage.style.display = "block";
      successMessage.style.display = "none";
    }
  }

  function setLoading(loading) {
    if (loading) {
      submitBtn.innerHTML =
        '<i class="fas fa-spinner fa-spin"></i> Processing...';
      submitBtn.disabled = true;
    } else {
      submitBtn.innerHTML = `<span id="btnText">${btnText.textContent}</span> <i class="fas fa-arrow-right"></i>`;
      submitBtn.disabled = false;
    }
  }

  /////stop

  // user validation
  /**function user(){
                if(usernameInput === '') {
                    throw new Error(data.error || 'Failed to send reset instructions');
                }
            }**/
  // Form validation
  function validateEmail(email) {
    const re =
      /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(String(email).toLowerCase());
  }

  function validatePassword(password) {
    return password.length >= 6;
  }

  function validateUsername(username) {
    return username;
  }

  // Real-time validation
  emailInput.addEventListener("input", function () {
    if (!validateEmail(emailInput.value) && emailInput.value.length > 0) {
      emailError.style.display = "block";
    } else {
      emailError.style.display = "none";
    }
  });

  passwordInput.addEventListener("input", function () {
    if (
      !validatePassword(passwordInput.value) &&
      passwordInput.value.length > 0
    ) {
      passwordError.style.display = "block";
    } else {
      passwordError.style.display = "none";
    }
  });

  // Form submission
  loginForm.addEventListener("submit", async function (e) {
    e.preventDefault();

    const email = emailInput.value;
    const password = passwordInput.value;
    const username = usernameInput.value;
    const isLoginMode = loginBtn.classList.contains("active");

    // Basic validation (keep your existing validation)
    if (!validateEmail(email) || !validatePassword(password)) {
      showMessage("Please fix validation errors", "error");
      return;
    }

    setLoading(true);

    try {
      if (isLoginMode) {
        await loginUser(username, email, password);
      } else {
        await registerUser(username, email, password);
      }
    } catch (error) {
      showMessage(error.message, "error");
    } finally {
      setLoading(false);
    }
  });

  // Google login button
  googleLoginBtn.addEventListener("click", function () {
    googleLoginBtn.innerHTML =
      '<i class="fas fa-spinner fa-spin"></i> Connecting to Google...';
    googleLoginBtn.disabled = true;

    // Simulate Google OAuth process
    setTimeout(function () {
      alert(
        "Google authentication initiated. In a real app, this would redirect to Google OAuth."
      );
      googleLoginBtn.innerHTML =
        '<div class="google-icon"></div><span>Continue with Google</span>';
      googleLoginBtn.disabled = false;
    }, 1000);
  });

  // Forgot password link
  document
    .querySelector(".forgot-password")
    .addEventListener("click", async function (e) {
      e.preventDefault();
      const email = prompt("Please enter your email to reset your password:");
      if (email && validateEmail(email)) {
        try {
          const result = await forgotPassword(email);
          alert(result.message);
        } catch (error) {
          alert(error.message);
        }
      } else if (email) {
        alert("Please enter a valid email address.");
      }
    });
});

