
// Add this JavaScript at the end of your original HTML file
// Replace the entire script section with this:


    // ===== BACKEND INTEGRATION =====
    const API_BASE_URL = 'http://localhost:5000/api';
    
    // DOM Elements (same as before, plus these new ones)
    const loginBtn = document.getElementById('loginBtn');
    const signupBtn = document.getElementById('signupBtn');
    const loginForm = document.getElementById('loginForm');
    const emailInput = document.getElementById('email');
    const passwordInput = document.getElementById('password');
    const emailError = document.getElementById('emailError');
    const passwordError = document.getElementById('passwordError');
    const submitBtn = document.getElementById('submitBtn');
    const btnText = document.getElementById('btnText');
    const googleLoginBtn = document.getElementById('googleLogin');
    
    // Add these new elements to your HTML:
    // Add this after the form, before the Google button:
    /*
    <div class="success-message" id="successMessage">
        <i class="fas fa-check-circle"></i> <span id="successText">Login successful!</span>
    </div>
    
    <div class="error-message" id="errorMessage">
        <i class="fas fa-exclamation-circle"></i> <span id="errorText">Error message</span>
    </div>
    */
    
    // Then add these CSS styles:
    /*
    .success-message {
        background-color: #d1fae5;
        color: #065f46;
        padding: 1rem;
        border-radius: 8px;
        margin-bottom: 1.5rem;
        display: none;
        text-align: center;
        border: 1px solid #a7f3d0;
    }
    
    .error-message {
        background-color: #fee2e2;
        color: #dc2626;
        padding: 1rem;
        border-radius: 8px;
        margin-bottom: 1.5rem;
        display: none;
        text-align: center;
        border: 1px solid #fecaca;
    }
    */
    
    // ===== BACKEND FUNCTIONS =====
    
    async function registerUser(email, password) {
        const response = await fetch(`${API_BASE_URL}/auth/register`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ email, password })
        });

        const data = await response.json();

        if (!response.ok) {
            throw new Error(data.error || 'Registration failed');
        }

        // Save token for future requests
        localStorage.setItem('authToken', data.token);
        
        showMessage('Registration successful!', 'success');
        
        // Simulate redirect
        setTimeout(() => {
            alert('Registration successful! You can now login.');
        }, 2000);
    }

    async function loginUser(email, password) {
        const response = await fetch(`${API_BASE_URL}/auth/login`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ email, password })
        });

        const data = await response.json();

        if (!response.ok) {
            throw new Error(data.error || 'Login failed');
        }

        // Save token for future requests
        localStorage.setItem('authToken', data.token);
        
        showMessage('Login successful! Redirecting...', 'success');
        
        // Simulate redirect
        setTimeout(() => {
            alert('Login successful! Welcome to your dashboard.');
        }, 2000);
    }

    async function forgotPassword(email) {
        const response = await fetch(`${API_BASE_URL}/auth/forgot-password`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ email })
        });

        const data = await response.json();

        if (!response.ok) {
            throw new Error(data.error || 'Failed to send reset instructions');
        }

        return data;
    }

    // ===== HELPER FUNCTIONS =====
    
    function showMessage(message, type = 'success') {
        // You need to add these elements to your HTML
        const successMessage = document.getElementById('successMessage');
        const errorMessage = document.getElementById('errorMessage');
        const successText = document.getElementById('successText');
        const errorText = document.getElementById('errorText');
        
        if (type === 'success') {
            successText.textContent = message;
            successMessage.style.display = 'block';
            errorMessage.style.display = 'none';
        } else {
            errorText.textContent = message;
            errorMessage.style.display = 'block';
            successMessage.style.display = 'none';
        }
    }
    
    function setLoading(loading) {
        if (loading) {
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Processing...';
            submitBtn.disabled = true;
        } else {
            submitBtn.innerHTML = `<span id="btnText">${btnText.textContent}</span> <i class="fas fa-arrow-right"></i>`;
            submitBtn.disabled = false;
        }
    }
    
    // ===== UPDATE FORM SUBMISSION =====
    // Replace your existing form submission code with this:
    
    loginForm.addEventListener('submit', async function(e) {
        e.preventDefault();
        
        const email = emailInput.value;
        const password = passwordInput.value;
        const isLoginMode = loginBtn.classList.contains('active');
        
        // Basic validation (keep your existing validation)
        if (!validateEmail(email) || !validatePassword(password)) {
            showMessage('Please fix validation errors', 'error');
            return;
        }
        
        setLoading(true);
        
        try {
            if (isLoginMode) {
                await loginUser(email, password);
            } else {
                await registerUser(email, password);
            }
        } catch (error) {
            showMessage(error.message, 'error');
        } finally {
            setLoading(false);
        }
    });
    
    // Update forgot password handler
    document.querySelector('.forgot-password').addEventListener('click', async function(e) {
        e.preventDefault();
        const email = prompt('Please enter your email to reset your password:');
        if (email && validateEmail(email)) {
            try {
                const result = await forgotPassword(email);
                alert(result.message);
            } catch (error) {
                alert(error.message);
            }
        } else if (email) {
            alert('Please enter a valid email address.');
        }
    });
    
    // Keep all your existing validation and UI code
    // Only replace the form submission part

