const API_URL = 'http://localhost:5000/api';

let authToken = localStorage.getItem('authToken');
let categories = [];
let editingCategoryId = null;

// DOM Elements
let backBtn, categoriesList, addNewBtn, modalOverlay, modalTitle, categoryForm, cancelBtn, saveBtn;

// 1. Save Category to Database - FIXED FOR YOUR DB SCHEMA
async function saveCategoryToDB(categoryData) {
    if (!authToken) {
        alert('Please login first');
        return null;
    }

    try {
        // TRANSFORM: Map frontend fields to database fields
        const dbCategoryData = {
            name: categoryData.name,
            icon: categoryData.icon,
            budget: categoryData.limit,
            spent: categoryData.spent,  // Your DB uses "budget" not "limit"
            // Note: Your DB doesn't have spent, status, or statusText
            // So we'll store them separately
        };

        const response = await fetch(`${API_URL}/categories`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${authToken}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(dbCategoryData)
        });

        const data = await response.json();
        
        if (response.ok) {
            console.log('✅ Category saved to database:', data);
            
            // Save spent amount to localStorage (since DB doesn't store it)
            if (categoryData.spent > 0) {
                localStorage.setItem(`category_spent_${data.category?.id || data.id}`, categoryData.spent);
            }
            
            // Save status to localStorage
            localStorage.setItem(`category_status_${data.category?.id || data.id}`, categoryData.status);
            localStorage.setItem(`category_statusText_${data.category?.id || data.id}`, categoryData.statusText);
            
            // Return transformed category with ALL fields
            return {
                id: data.category?.id || data.id,
                name: data.category?.name || categoryData.name,
                icon: data.category?.icon || categoryData.icon,
                spent: categoryData.spent,  // From frontend input
                limit: data.category?.budget || categoryData.limit,  // Map "budget" to "limit"
                status: categoryData.status,  // From frontend calculation
                statusText: categoryData.statusText  // From frontend calculation
            };
        } else {
            console.error('❌ Save failed:', data.error);
            alert('Save failed: ' + data.error);
            return null;
        }
    } catch (error) {
        console.error('❌ Network error:', error);
        alert('Network error - check if backend is running');
        return null;
    }
}

// 2. Update Category in Database - FIXED FOR YOUR DB SCHEMA
async function updateCategoryInDB(categoryId, updates) {
    try {
        // TRANSFORM: Map frontend fields to database fields
        const dbUpdates = {
            name: updates.name,
            icon: updates.icon,
            budget: updates.limit,
            spent: updates.spent,  // Your DB uses "budget" not "limit"
        };

        const response = await fetch(`${API_URL}/categories/${categoryId}`, {
            method: 'PUT',
            headers: {
                'Authorization': `Bearer ${authToken}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(dbUpdates)
        });

        const data = await response.json();
        
        if (response.ok) {
            console.log('✅ Category updated in database');
            
            // Update localStorage with spent amount
            if (updates.spent > 0) {
                localStorage.setItem(`category_spent_${categoryId}`, updates.spent);
            } else {
                localStorage.removeItem(`category_spent_${categoryId}`);
            }
            
            // Update localStorage with status
            localStorage.setItem(`category_status_${categoryId}`, updates.status);
            localStorage.setItem(`category_statusText_${categoryId}`, updates.statusText);
            
            return true;
        } else {
            console.error('❌ Update failed:', data.error);
            return false;
        }
    } catch (error) {
        console.error('❌ Update error:', error);
        return false;
    }
}

// 3. Delete Category from Database - FIXED
async function deleteCategoryFromDB(categoryId) {
    try {
        const response = await fetch(`${API_URL}/categories/${categoryId}`, {
            method: 'DELETE',
            headers: {
                'Authorization': `Bearer ${authToken}`
            }
        });

        const data = await response.json();
        
        if (response.ok) {
            console.log('✅ Category deleted from database');
            
            // Clean up localStorage data
            localStorage.removeItem(`category_spent_${categoryId}`);
            localStorage.removeItem(`category_status_${categoryId}`);
            localStorage.removeItem(`category_statusText_${categoryId}`);
            
            return true;
        } else {
            console.error('❌ Delete failed:', data.error);
            return false;
        }
    } catch (error) {
        console.error('❌ Delete error:', error);
        return false;
    }
}

// 4. Load Categories from Database - FIXED FOR YOUR DB SCHEMA
async function loadCategoriesFromDB() {
    if (!authToken) {
        console.log('Not logged in, skipping DB load');
        return [];
    }

    try {
        const response = await fetch(`${API_URL}/categories`, {
            headers: {
                'Authorization': `Bearer ${authToken}`
            }
        });

        const data = await response.json();
        
        if (response.ok) {
            console.log('📥 Raw data from backend:', data);
            
            // TRANSFORM: Map database fields to frontend fields
            const transformedCategories = (data.categories || data || []).map(cat => {
                // Load spent from localStorage (since DB doesn't store it)
                const spent = parseInt(localStorage.getItem(`category_spent_${cat.id}`)) || 0;
                //const spent = cat.spent !== undefined ? cat.spent : (parseInt(localStorage.getItem(`category_spent${cat.id}`)) || 0);
                
                // Load status from localStorage
                const status = localStorage.getItem(`category_status_${cat.id}`) || 'good';
                const statusText = localStorage.getItem(`category_statusText_${cat.id}`) || 'Good';
                
                // Calculate status if not in localStorage (for backward compatibility)
                let finalStatus = status;
                let finalStatusText = statusText;
                const limit = cat.budget || 0;
                
                if (spent === 0) {
                    finalStatus = "good";
                    finalStatusText = "Good";
                } else if (spent >= limit) {
                    finalStatus = "paid";
                    finalStatusText = "Paid";
                } else if (spent >= limit * 0.7) {
                    finalStatus = "warning";
                    finalStatusText = "Warning";
                } else {
                    finalStatus = "good";
                    finalStatusText = "Good";
                }
                
                return {
                    id: cat.id,
                    name: cat.name || 'Unnamed Category',
                    icon: cat.icon || 'other',
                    spent: spent,
                    limit: cat.budget || 0,  // Map "budget" to "limit"
                    status: finalStatus,
                    statusText: finalStatusText
                };
            });
            
            console.log('📥 Transformed categories:', transformedCategories);
            return transformedCategories;
        } else {
            console.error('❌ Load failed:', data.error);
            return [];
        }
    } catch (error) {
        console.error('❌ Load error:', error);
        return [];
    }
}

document.addEventListener('DOMContentLoaded', function() {
    // Get DOM Elements
    backBtn = document.getElementById('backBtn');
    categoriesList = document.getElementById('categoriesList');
    addNewBtn = document.getElementById('addNewBtn');
    modalOverlay = document.getElementById('modalOverlay');
    modalTitle = document.getElementById('modalTitle');
    categoryForm = document.getElementById('categoryForm');
    cancelBtn = document.getElementById('cancelBtn');
    saveBtn = document.getElementById('saveBtn');

    // Initialize page - Load data from backend
    initializePage();

    // Back button functionality
    backBtn.addEventListener('click', function() {
        window.history.back();
    });

    // Add new category button
    addNewBtn.addEventListener('click', function() {
        editingCategoryId = null;
        modalTitle.textContent = "Add New Category";
        categoryForm.reset();
        modalOverlay.style.display = "flex";
    });

    // Cancel button in modal
    cancelBtn.addEventListener('click', function() {
        modalOverlay.style.display = "none";
        categoryForm.reset();
        editingCategoryId = null;
    });

    // Close modal when clicking outside
    modalOverlay.addEventListener('click', function(e) {
        if (e.target === modalOverlay) {
            modalOverlay.style.display = "none";
            categoryForm.reset();
            editingCategoryId = null;
        }
    });

    // Form submission - FIXED
    categoryForm.addEventListener('submit', async function(e) {
        e.preventDefault();
        
        const name = document.getElementById('categoryName').value;
        const icon = document.getElementById('categoryIcon').value;
        const limit = parseInt(document.getElementById('categoryLimit').value) || 0;
        const spentInput = document.getElementById('categorySpent').value;
        const spent = spentInput ? parseInt(spentInput) : 0;

        // Determine status based on spending
        let status, statusText;
        if (spent === 0) {
            status = "good";
            statusText = "Good";
        } else if (spent >= limit) {
            status = "paid";
            statusText = "Paid";
        } else if (spent >= limit * 0.7) {
            status = "warning";
            statusText = "Warning";
        } else {
            status = "good";
            statusText = "Good";
        }

        const categoryData = {
            name,
            icon,
            spent,
            limit,
            status,
            statusText
        };

        console.log('📤 Saving category data:', categoryData);

        if (editingCategoryId) {
            // Update existing category in backend
            const success = await updateCategoryInDB(editingCategoryId, categoryData);
            
            if (success) {
                // Update local cache
                const index = categories.findIndex(cat => cat.id === editingCategoryId);
                if (index !== -1) {
                    categories[index] = {
                        ...categories[index],
                        ...categoryData
                    };
                }
            }
        } else {
            // Add new category to backend
            const savedCategory = await saveCategoryToDB(categoryData);
            
            if (savedCategory) {
                categories.push(savedCategory);
            }
        }

        // Update UI
        renderCategories();
        modalOverlay.style.display = "none";
        categoryForm.reset();
        editingCategoryId = null;
    });
});

// Initialize page - Load data from backend
async function initializePage() {
    // Load categories from database
    categories = await loadCategoriesFromDB();

    // If no data from backend, use local fallback
    if (categories.length === 0) {
        console.log('Using local fallback data');
        categories = [
            {
                id: 1,
                name: "Food",
                icon: "food",
                spent: 350,
                limit: 500,
                status: "good",
                statusText: "Good"
            },
            {
                id: 2,
                name: "Rent",
                icon: "rent",
                spent: 1200,
                limit: 1200,
                status: "paid",
                statusText: "Paid"
            },
            {
                id: 3,
                name: "Fun",
                icon: "fun",
                spent: 45,
                limit: 100,
                status: "warning",
                statusText: "Warning"
            }
        ];
    }
    
    console.log('📊 Final categories:', categories);
    renderCategories();
}

// REST OF YOUR FUNCTIONS STAY THE SAME (renderCategories, getIconSymbol, editCategory, deleteCategory)
// Just copy them from your original file - they don't need changes

// Function to render categories
function renderCategories() {
    categoriesList.innerHTML = "";
    
    categories.forEach(category => {
        const card = document.createElement('div');
        card.className = 'category-card';

        // Calculate percentage for progress bar
        const spent = category.spent || 0;
        const limit = category.limit || 0;
        const percentage = limit > 0 ? Math.min((spent / limit) * 100, 100) : 0;

        // Get icon class
        const iconClass = `icon-${category.icon}`;

        // Get status class
        const statusClass = `status-${category.status}`;

        // Get progress fill class
        let fillClass = "";
        if (category.icon === "food") fillClass = "fill-good";
        else if (category.icon === "fun") fillClass = "fill-fun";
        else if (category.icon === "transport") fillClass = "fill-transport";
        else if (category.icon === "utilities") fillClass = "fill-utilities";
        else if (category.icon === "education") fillClass = "fill-education";
        else fillClass = "fill-good";

        // Create card HTML
        card.innerHTML = `
            <div class="category-header">
                <div class="category-name">
                    <div class="category-icon ${iconClass}">
                        ${getIconSymbol(category.icon)}
                    </div>
                    <span>${category.name}</span>
                </div>
                <div class="category-status ${statusClass}">${category.statusText}</div>
            </div>
            
            ${category.status === "paid" 
                ? `<div class="paid-message">Paid</div>` 
                : `
                    <div class="category-progress">
                        <div class="progress-info">
                            <span class="progress-amount">$${spent} / $${limit}</span>
                            <span class="progress-limit">${percentage.toFixed(0)}%</span>
                        </div>
                        <div class="progress-bar">
                            <div class="progress-fill ${fillClass}" style="width: ${percentage}%"></div>
                        </div>
                    </div>
                `}
            
            <div class="category-actions">
                <button class="action-btn action-edit" data-id="${category.id}">
                    <i class="fas fa-edit"></i>
                    <span>Edit</span>
                </button>
                <button class="action-btn action-delete" data-id="${category.id}">
                    <i class="fas fa-trash"></i>
                    <span>Delete</span>
                </button>
            </div>
        `;

        categoriesList.appendChild(card);
    });

    // Add event listeners to edit and delete buttons
    document.querySelectorAll('.action-edit').forEach(btn => {
        btn.addEventListener('click', function() {
            const id = parseInt(this.getAttribute('data-id'));
            editCategory(id);
        });
    });

    document.querySelectorAll('.action-delete').forEach(btn => {
        btn.addEventListener('click', function() {
            const id = parseInt(this.getAttribute('data-id'));
            deleteCategory(id);
        });
    });
}

// Function to get icon symbol
function getIconSymbol(icon) {
    const icons = {
        food: "🍔",
        rent: "🏠",
        fun: "🎉",
        transport: "🚗",
        utilities: "💡",
        education: "📚",
        shopping: "🛍️",
        health: "🏥",
        travel: "✈️",
        other: "📁"
    };
    
    return icons[icon] || "📁";
}

// Function to edit category
function editCategory(id) {
    const category = categories.find(cat => cat.id === id);
    if (!category) return;

    editingCategoryId = id;
    modalTitle.textContent = "Edit Category";
    document.getElementById('categoryName').value = category.name;
    document.getElementById('categoryIcon').value = category.icon;
    document.getElementById('categoryLimit').value = category.limit || 0;
    document.getElementById('categorySpent').value = category.spent || 0;
    modalOverlay.style.display = "flex";
}

// Function to delete category
async function deleteCategory(id) {
    if (confirm("Are you sure you want to delete this category?")) {
        const success = await deleteCategoryFromDB(id);
        
        if (success) {
            categories = categories.filter(cat => cat.id !== id);
            renderCategories();
        } else {
            alert('Failed to delete category from server');
        }
    }
}
