
        document.addEventListener('DOMContentLoaded', function() {
            // DOM Elements
            const backBtn = document.getElementById('backBtn');
            const categoriesList = document.getElementById('categoriesList');
            const addNewBtn = document.getElementById('addNewBtn');
            const modalOverlay = document.getElementById('modalOverlay');
            const modalTitle = document.getElementById('modalTitle');
            const categoryForm = document.getElementById('categoryForm');
            const cancelBtn = document.getElementById('cancelBtn');
            const saveBtn = document.getElementById('saveBtn');
            
            // Category data
            let categories = [
                {
                    id: 1,
                    name: "Food",
                    icon: "food",
                    spent: 350,
                    limit: 500,
                    status: "good",
                    statusText: "Good"
                },
                {
                    id: 2,
                    name: "Rent",
                    icon: "rent",
                    spent: 1200,
                    limit: 1200,
                    status: "paid",
                    statusText: "Paid"
                },
                {
                    id: 3,
                    name: "Fun",
                    icon: "fun",
                    spent: 45,
                    limit: 100,
                    status: "warning",
                    statusText: "Warning"
                },
                {
                    id: 4,
                    name: "Transport",
                    icon: "transport",
                    spent: 80,
                    limit: 150,
                    status: "warning",
                    statusText: "Warning"
                },
                {
                    id: 5,
                    name: "Utilities",
                    icon: "utilities",
                    spent: 120,
                    limit: 200,
                    status: "warning",
                    statusText: "Warning"
                },
                {
                    id: 6,
                    name: "Education",
                    icon: "education",
                    spent: 0,
                    limit: 1200,
                    status: "good",
                    statusText: "Good"
                }
            ];
            
            let editingCategoryId = null;
            
            // Initialize page
            renderCategories();
            
            // Back button functionality
            backBtn.addEventListener('click', function() {
                window.history.back();
            });
            
            // Add new category button
            addNewBtn.addEventListener('click', function() {
                editingCategoryId = null;
                modalTitle.textContent = "Add New Category";
                categoryForm.reset();
                modalOverlay.style.display = "flex";
            });
            
            // Cancel button in modal
            cancelBtn.addEventListener('click', function() {
                modalOverlay.style.display = "none";
                categoryForm.reset();
                editingCategoryId = null;
            });
            
            // Close modal when clicking outside
            modalOverlay.addEventListener('click', function(e) {
                if (e.target === modalOverlay) {
                    modalOverlay.style.display = "none";
                    categoryForm.reset();
                    editingCategoryId = null;
                }
            });
            
            // Form submission
            categoryForm.addEventListener('submit', function(e) {
                e.preventDefault();
                
                const name = document.getElementById('categoryName').value;
                const icon = document.getElementById('categoryIcon').value;
                const limit = parseInt(document.getElementById('categoryLimit').value);
                const spentInput = document.getElementById('categorySpent').value;
                const spent = spentInput ? parseInt(spentInput) : 0;
                
                // Determine status based on spending
                let status, statusText;
                if (spent === 0) {
                    status = "good";
                    statusText = "Good";
                } else if (spent >= limit) {
                    status = "paid";
                    statusText = "Paid";
                } else if (spent >= limit * 0.7) {
                    status = "warning";
                    statusText = "Warning";
                } else {
                    status = "good";
                    statusText = "Good";
                }
                
                if (editingCategoryId) {
                    // Update existing category
                    const index = categories.findIndex(cat => cat.id === editingCategoryId);
                    if (index !== -1) {
                        categories[index] = {
                            ...categories[index],
                            name,
                            icon,
                            spent,
                            limit,
                            status,
                            statusText
                        };
                    }
                } else {
                    // Add new category
                    const newId = categories.length > 0 ? Math.max(...categories.map(cat => cat.id)) + 1 : 1;
                    categories.push({
                        id: newId,
                        name,
                        icon,
                        spent,
                        limit,
                        status,
                        statusText
                    });
                }
                
                // Update UI
                renderCategories();
                modalOverlay.style.display = "none";
                categoryForm.reset();
                editingCategoryId = null;
            });
            
            // Function to render categories
            function renderCategories() {
                categoriesList.innerHTML = "";
                
                categories.forEach(category => {
                    const card = document.createElement('div');
                    card.className = 'category-card';
                    
                    // Calculate percentage for progress bar
                    const percentage = category.limit > 0 ? Math.min((category.spent / category.limit) * 100, 100) : 0;
                    
                    // Get icon class
                    const iconClass = `icon-${category.icon}`;
                    
                    // Get status class
                    const statusClass = `status-${category.status}`;
                    
                    // Get progress fill class
                    let fillClass = "";
                    if (category.icon === "food") fillClass = "fill-good";
                    else if (category.icon === "fun") fillClass = "fill-fun";
                    else if (category.icon === "transport") fillClass = "fill-transport";
                    else if (category.icon === "utilities") fillClass = "fill-utilities";
                    else if (category.icon === "education") fillClass = "fill-education";
                    else fillClass = "fill-good";
                    
                    // Create card HTML
                    card.innerHTML = `
                        <div class="category-header">
                            <div class="category-name">
                                <div class="category-icon ${iconClass}">
                                    ${getIconSymbol(category.icon)}
                                </div>
                                <span>${category.name}</span>
                            </div>
                            <div class="category-status ${statusClass}">${category.statusText}</div>
                        </div>
                        
                        ${category.status === "paid" 
                            ? `<div class="paid-message">Paid</div>` 
                            : `
                                <div class="category-progress">
                                    <div class="progress-info">
                                        <span class="progress-amount">$${category.spent} / $${category.limit}</span>
                                        <span class="progress-limit">${percentage.toFixed(0)}%</span>
                                    </div>
                                    <div class="progress-bar">
                                        <div class="progress-fill ${fillClass}" style="width: ${percentage}%"></div>
                                    </div>
                                </div>
                            `
                        }
                        
                        <div class="category-actions">
                            <button class="action-btn action-edit" data-id="${category.id}">
                                <i class="fas fa-edit"></i>
                                <span>Edit</span>
                            </button>
                            <button class="action-btn action-delete" data-id="${category.id}">
                                <i class="fas fa-trash"></i>
                                <span>Delete</span>
                            </button>
                        </div>
                    `;
                    
                    categoriesList.appendChild(card);
                });
                
                // Add event listeners to edit and delete buttons
                document.querySelectorAll('.action-edit').forEach(btn => {
                    btn.addEventListener('click', function() {
                        const id = parseInt(this.getAttribute('data-id'));
                        editCategory(id);
                    });
                });
                
                document.querySelectorAll('.action-delete').forEach(btn => {
                    btn.addEventListener('click', function() {
                        const id = parseInt(this.getAttribute('data-id'));
                        deleteCategory(id);
                    });
                });
            }
            
            // Function to get icon symbol
            function getIconSymbol(icon) {
                const icons = {
                    food: "🍔",
                    rent: "🏠",
                    fun: "🎉",
                    transport: "🚗",
                    utilities: "💡",
                    education: "📚",
                    shopping: "🛍️",
                    health: "🏥",
                    travel: "✈️",
                    other: "📁"
                };
                return icons[icon] || "📁";
            }
            
            // Function to edit category
            function editCategory(id) {
                const category = categories.find(cat => cat.id === id);
                if (!category) return;
                
                editingCategoryId = id;
                modalTitle.textContent = "Edit Category";
                
                document.getElementById('categoryName').value = category.name;
                document.getElementById('categoryIcon').value = category.icon;
                document.getElementById('categoryLimit').value = category.limit;
                document.getElementById('categorySpent').value = category.spent;
                
                modalOverlay.style.display = "flex";
            }
            
            // Function to delete category
            function deleteCategory(id) {
                if (confirm("Are you sure you want to delete this category?")) {
                    categories = categories.filter(cat => cat.id !== id);
                    renderCategories();
                }
            }
        });