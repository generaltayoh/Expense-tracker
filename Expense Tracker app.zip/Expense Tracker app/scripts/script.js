
        document.addEventListener('DOMContentLoaded', function() {
            // DOM Elements
            const loginBtn = document.getElementById('loginBtn');
            const signupBtn = document.getElementById('signupBtn');
            const loginForm = document.getElementById('loginForm');
            const usernameInput = document.getElementById('username');
            const emailInput = document.getElementById('email');
            const passwordInput = document.getElementById('password');
            const emailError = document.getElementById('emailError');
            const passwordError = document.getElementById('passwordError');
            const submitBtn = document.getElementById('submitBtn');
            const btnText = document.getElementById('btnText');
            const googleLoginBtn = document.getElementById('googleLogin');
            const successMessage = document.getElementById('successMessage');
            
            // Toggle between Login and Sign Up
            loginBtn.addEventListener('click', function() {
                loginBtn.classList.add('active');
                signupBtn.classList.remove('active');
                btnText.textContent = 'Log In';
                document.querySelector('.login-title').textContent = 'Welcome Back';
                document.querySelector('.login-header p').textContent = 'Log in to continue managing your finances';
            });
            
            signupBtn.addEventListener('click', function() {
                signupBtn.classList.add('active');
                loginBtn.classList.remove('active');
                btnText.textContent = 'Sign Up';
                document.querySelector('.login-title').textContent = 'Create Account';
                document.querySelector('.login-header p').textContent = 'Sign up to start tracking your expenses';
            });
            
            // Form validation
            function validateEmail(email) {
                const re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
                return re.test(String(email).toLowerCase());
            }
            
            function validatePassword(password) {
                return password.length >= 6;
            }
            
            // Real-time validation
            emailInput.addEventListener('input', function() {
                if (!validateEmail(emailInput.value) && emailInput.value.length > 0) {
                    emailError.style.display = 'block';
                } else {
                    emailError.style.display = 'none';
                }
            });
            
            passwordInput.addEventListener('input', function() {
                if (!validatePassword(passwordInput.value) && passwordInput.value.length > 0) {
                    passwordError.style.display = 'block';
                } else {
                    passwordError.style.display = 'none';
                }
            });
            
            // Form submission
            loginForm.addEventListener('submit', function(e) {
                e.preventDefault();
                
                const email = emailInput.value;
                const password = passwordInput.value;
                const username = usernameInput.value;
                let isValid = true;
                
                // Reset errors
                emailError.style.display = 'none';
                passwordError.style.display = 'none';
                
                // Validate email
                if (!validateEmail(email)) {
                    emailError.style.display = 'block';
                    isValid = false;
                }
                
                // Validate password
                if (!validatePassword(password)) {
                    passwordError.style.display = 'block';
                    isValid = false;
                }
                
                if (isValid) {
                    // Show loading state
                    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Processing...';
                    submitBtn.disabled = true;
                    
                    // Simulate API call
                    setTimeout(function() {
                        // Show success message
                        successMessage.style.display = 'block';
                        
                        // Reset form
                        loginForm.reset();
                        
                        // Reset button
                        submitBtn.innerHTML = '<span id="btnText">' + btnText.textContent + '</span> <i class="fas fa-arrow-right"></i>';
                        submitBtn.disabled = false;
                        
                        // Simulate redirect after 2 seconds
                        setTimeout(function() {
                            alert(btnText.textContent + ' successful! In a real app, you would be redirected to the dashboard.');
                            successMessage.style.display = 'none';
                        }, 2000);
                    }, 1500);
                }
            });
            
            // Google login button
            googleLoginBtn.addEventListener('click', function() {
                googleLoginBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Connecting to Google...';
                googleLoginBtn.disabled = true;
                
                // Simulate Google OAuth process
                setTimeout(function() {
                    alert('Google authentication initiated. In a real app, this would redirect to Google OAuth.');
                    googleLoginBtn.innerHTML = '<div class="google-icon"></div><span>Continue with Google</span>';
                    googleLoginBtn.disabled = false;
                }, 1000);
            });
            
            // Forgot password link
            document.querySelector('.forgot-password').addEventListener('click', function(e) {
                e.preventDefault();
                const email = prompt('Please enter your email to reset your password:');
                if (email && validateEmail(email)) {
                    alert('Password reset instructions have been sent to ' + email);
                } else if (email) {
                    alert('Please enter a valid email address.');
                }
            });
        });