const Login = document.getElementsByClassName("Login");
const Signup = document.getElementsByClassName("Signup");
let showLogin = document.getElementsByClassName("ShowLogin");
let showSignup = document.getElementsByClassName("ShowSignup");
showLogin.addEventListener('click', function(){
    Login.style.display =" block"
    Signup.style.display ="none";
});
showSignup.addEventListener('click', function(){
    Login.style.display="none"
    Signup.style.display ="block";
});
